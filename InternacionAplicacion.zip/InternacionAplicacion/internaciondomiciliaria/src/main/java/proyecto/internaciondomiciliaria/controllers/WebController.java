package proyecto.internaciondomiciliaria.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import proyecto.internaciondomiciliaria.entities.Chofer;
import proyecto.internaciondomiciliaria.entities.Equipo;
import proyecto.internaciondomiciliaria.entities.Paciente;
import proyecto.internaciondomiciliaria.entities.Visita;
import proyecto.internaciondomiciliaria.enums.Horario;
import proyecto.internaciondomiciliaria.repositories.ChoferRepository;
import proyecto.internaciondomiciliaria.repositories.EquipoRepository;
import proyecto.internaciondomiciliaria.repositories.PacienteRepository;
import proyecto.internaciondomiciliaria.repositories.VisitaRepository;

@Controller
public class WebController {
   
    
    private PacienteRepository pacienteRepository=new PacienteRepository();
    private EquipoRepository equipoRepository=new EquipoRepository();
    private ChoferRepository choferRepository= new ChoferRepository();
    private VisitaRepository visitaRepository=new VisitaRepository();

    private String mensajePaciente="Ingrese un nuevo Paciente!";
    private String mensajeEquipo="Ingrese un nuevo Equipo!";
    private String mensajeChofer="Ingrese un nuevo Chofer!";
    private String mensajeVisita="Ingrese una nueva Visita!";
    

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/pacientes")
    
    public String getPacientes(@RequestParam(name="buscarNombre", required = false, defaultValue="") String buscarNombre,
                                 Model model){
        model.addAttribute("mensajePaciente", mensajePaciente);
        model.addAttribute("paciente", new Paciente());
        //model.addAttribute("cursos", cursoRepository.getAll());
        model.addAttribute("likeNombre", pacienteRepository.getLikePacienteNombre(buscarNombre));//MODIFICAR
        return "pacientes";
    }

    @GetMapping("/equipos")
    public String getAlumnos(@RequestParam(name="buscarEquipo", required = false, defaultValue="") String buscarEquipo,
                    Model model){
        model.addAttribute("mensajeEquipo", mensajeEquipo);
        model.addAttribute("equipo", new Equipo());
        model.addAttribute("likeEquipo", equipoRepository.getLikeEquipoDescripcion(buscarEquipo));
        model.addAttribute("equipos", equipoRepository.getAll());
        return "alumnos";
    }

    @PostMapping("/savePaciente")
    public String save(@ModelAttribute Paciente paciente){
        try {
            pacienteRepository.save(paciente);
            mensajePaciente="Se guardo el paciente id: "+paciente.getId_paciente();
        } catch (Exception e) {
            mensajePaciente="Ocurrio un error";
        }
        return "redirect:pacientes";
    }

    @PostMapping("/saveEquipo")
    public String save(@ModelAttribute Equipo equipo){
        try {
            equipoRepository.save(equipo);
            mensajeEquipo="Se guardo el equipo id: "+equipo.getId_equipo();
        } catch (Exception e) {
            mensajeEquipo="Ocurrio un error";
        }
        return "redirect:equipos";
    }
}


