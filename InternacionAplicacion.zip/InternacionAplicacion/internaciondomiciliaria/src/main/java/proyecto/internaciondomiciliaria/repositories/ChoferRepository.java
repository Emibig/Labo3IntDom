package proyecto.internaciondomiciliaria.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import proyecto.internaciondomiciliaria.connectors.*;
import proyecto.internaciondomiciliaria.entities.Chofer;

public class ChoferRepository {

    private Connection conn = Connector.getConnection();

    public void save(Chofer chofer) {
        if (chofer == null)
            return;

        try (PreparedStatement ps = conn.prepareStatement(
                "insert into choferes (vehiculo, nombre_chofer, zona) values (?,?,?)",

                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, chofer.getVehiculo());
            ps.setString(2, chofer.getNombre_chofer());
            ps.setString(3, chofer.getZona());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                chofer.setId_chofer(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Chofer chofer) {
        if (chofer == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from choferes where id_chofer=?")) {
            ps.setInt(1, chofer.getId_chofer());
            ps.execute();
        } catch (Exception e) {
            System.out.print(e);
        }
    };

    public void update(Chofer chofer) {
        if (chofer == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update choferes set zona = ?,vehiculo=?,nombre_chofer=? where id_chofer=?")) {
            ps.setString(1, chofer.getZona());
            ps.setString(2, chofer.getVehiculo());
            ps.setString(3, chofer.getNombre_chofer());
            ps.setInt(4, chofer.getId_chofer());
            ps.execute();
        } catch (Exception e) {
            System.out.print(e);
        }
    };

    public List<Chofer> getAll() {
        List<Chofer> list = new ArrayList<Chofer>();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from choferes")) {
            while (rs.next()) {
                list.add(new Chofer(
                        rs.getInt("id_chofer"), // id chofer
                        rs.getString("vehiculo"),
                        rs.getString("nombre_chofer"),
                        rs.getString("zona")

                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Chofer getByChoferId(int id_chofer) {
        return getAll()
                .stream()
                .filter(a -> a.getId_chofer() == id_chofer)
                .findAny()
                .orElse(new Chofer());
    }

    public List<Chofer> getLikeChoferNombre(String nombre_chofer) {
        if (nombre_chofer == null)
            return new ArrayList<Chofer>();
        return getAll()
                .stream()
                .filter(a -> a.getNombre_chofer().toLowerCase().contains(nombre_chofer.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<Chofer> getLikeChoferVehiculo(String vehiculo) {
        if (vehiculo == null)
            return new ArrayList<Chofer>();
        return getAll()
                .stream()
                .filter(c -> c.getVehiculo().toLowerCase().contains(vehiculo.toLowerCase()))
                .toList();
    }

    /* filtra por nombre_chofer y zona */
    public List<Chofer> getLikeChoferNombreAndZona(String nombre_chofer, String zona) {
        if (nombre_chofer == null || zona == null)
            return new ArrayList<Chofer>();
        return getAll()
                .stream()
                .filter(a -> a.getNombre_chofer().toLowerCase().contains(nombre_chofer.toLowerCase())
                        && a.getZona().toLowerCase().contains(zona.toLowerCase()))
                .collect(Collectors.toList());
    }

}
