package proyecto.internaciondomiciliaria.test;

import proyecto.internaciondomiciliaria.entities.Chofer;
import proyecto.internaciondomiciliaria.entities.Equipo;
import proyecto.internaciondomiciliaria.entities.Paciente;
import proyecto.internaciondomiciliaria.entities.Visita;
import proyecto.internaciondomiciliaria.enums.Horario;
import proyecto.internaciondomiciliaria.repositories.ChoferRepository;
import proyecto.internaciondomiciliaria.repositories.EquipoRepository;
import proyecto.internaciondomiciliaria.repositories.PacienteRepository;
import proyecto.internaciondomiciliaria.repositories.VisitaRepository;

public class TestRepository {

    public static void main(String[] args) {

        System.out.println("***************save ****************************");

        PacienteRepository cr = new PacienteRepository();
        Paciente paciente = new Paciente("Zorba Zulma", 11112222, "ZRM", 1511112222,
                "Zapiola 1000",
                "PB", " Z y A ", "CABA", "uno");

        cr.save(paciente);
        System.out.println(paciente);

        System.out.println("***************getAll****************************");
        cr.getAll().forEach(System.out::println);

        System.out.println("***************paciente por ID(2)****************");
        System.out.println(cr.getByPacienteId(2));// ES BAUTISTA SALOMON

        System.out.println("***************paciente por Nombre***************");
        cr.getLikePacienteNombre("Liliana").forEach(System.out::println);// ES LILIANA GUERRERO

        System.out.println("****************por numero de socio***************");
        System.out.println(cr.getByPacienteNroSocio(11112222));// es Zorba Zulma

        System.out.println("****************por prepaga(cliente)***************");
        System.out.println(cr.getLikeCliente("osde"));

        System.out.println("****************por nombre y cliente *************");
        System.out.println(cr.getLikePacienteNombreAndCliente("Mendoza Elvira Elina",
                "osde"));

        System.out.println("**************por nombre y zona ******************");
        System.out.println(cr.getLikePacienteNombreAgrupadoZona("Niev Amparo",
                "sur"));

        System.out.println("************BORRAR paciente por ID*****************");
        cr.remove(cr.getByPacienteId(15));// borro a ZULMA
        cr.getAll().forEach(System.out::println);

        System.out.println("******************UPDATE paciente *****************");
        paciente = cr.getByPacienteId(8);
        paciente.setNombre("Dora la exploradora");
        cr.update(paciente);

        System.out.println(cr.getByPacienteId(8));

        System.out.println("****************************************EQUIPOS: save ****************************");

        EquipoRepository eq = new EquipoRepository();
        Equipo equipo = new Equipo("Levanta paciente hidraulico", 1301, 1);
        eq.save(equipo);
        System.out.println(equipo);

        System.out.println("***************get all**************************");
        eq.getAll().forEach(System.out::println);

        System.out.println("***************equipo por ID(2)****************");
        System.out.println(eq.getByEquipoId(2));// colchon de aire
        System.out.println("******************************");

        System.out.println("***************equipo por descripcion (todo silla de ruedas)**************");
        eq.getLikeEquipoDescripcion("Silla de ruedas").forEach(System.out::println);

        System.out.println("***********codigo interno, (405 eleva inodoro, pcte id 5 guerrero liliana)**********");
        System.out.println(eq.getByEquipoCodigoInterno(405));

        System.out.println("*******************equipo y paciente***********************");
        System.out.println(eq.getLikeEquipoAndIdPaciente(12, "Colchon de aire"));

        System.out.println("********totales de equipos por ID paciente(Salomon id 2, tiene 2 equipos***************");
        System.out.println("el paciente ID " + eq.getLikeEquipoTotalPorIdPaciente(2)
                + "equipos en total");// BATISTA SALOMON TIENE 2 EQUIPOS, CAMA Y CAIRE

    

        System.out.println("************BORRAR equipo por ID(15)***********************************");
        eq.remove(eq.getByEquipoId(15));// borro levanta paciente id 15
        eq.getAll().forEach(System.out::println);

        System.out.println("******************UPDATE equipo *****************");
        equipo = eq.getByEquipoCodigoInterno(405);
        equipo.setDescripcion("Eleva de inodoro de aluminio con ruedas y balde");
        eq.update(equipo);

        System.out.println(eq.getByEquipoCodigoInterno(405));



        System.out.println("*******************************************CHOFER: save *********************************");
        ChoferRepository ch = new ChoferRepository();
        Chofer chofer = new Chofer("Fiorino", "Maxi", "dos");
        ch.save(chofer);
        System.out.println(chofer);

        System.out.println("***************get all***********************************");
        ch.getAll().forEach(System.out::println);

        System.out.println("***************chofer por ID(1=Renzo)********************");
        System.out.println(ch.getByChoferId(1));//

        System.out.println("***************chofer por Nombre (Gabriel)************************");
        ch.getLikeChoferNombre("Gabriel").forEach(System.out::println);

        System.out.println("***************chofer por Vehiculo (Fiorino)**********************");
        System.out.println(ch.getLikeChoferVehiculo("Fiorino"));
        // ch.getLikeChoferVehiculo("Fiorino").forEach(System.out::println);
        ch.getLikeChoferVehiculo("Fiorino").forEach(System.out::println);

        System.out.println("***************chofer por Nombre y zona (Gabriel, sur)************");
        ch.getLikeChoferNombreAndZona("Gabriel", "sur").forEach(System.out::println);

        System.out.println("************BORRAR chofer por ID(7)***********************************");
        ch.remove(ch.getByChoferId(9));
        // ch.remove(ch.getByChoferId(7));
        ch.getAll().forEach(System.out::println);

        System.out.println("******************UPDATE chofer *****************");
        chofer = ch.getByChoferId(1);
        chofer.setNombre_chofer("Renzo Urzino");
        ch.update(chofer);

        System.out.println(ch.getByChoferId(1));

        System.out.println("****************************************VISITA: save ****************************");

        VisitaRepository vs = new VisitaRepository();
        Visita visita = new Visita(1, "Renzo", 2, "uno", "20-06-2023", Horario._9hs, Horario._13hs, "ok",
                "a verificar");
        vs.save(visita);
        System.out.println(visita);

        System.out.println("***************get all**************************");
        vs.getAll().forEach(System.out::println);

        System.out.println("***************visita por ID(3) ****************");
        System.out.println(vs.getByVisitaId(3));

        System.out.println("***************visita por fecha 24/5**************");
        vs.getByVisitaFecha("24-05-2023").forEach(System.out::println);

        System.out.println("***************visita por fecha 24/5 y zona**************");
        vs.getByVisitaFechaAndZona("24-05-2023", "oeste").forEach(System.out::println);

        System.out.println("***************visita ok y zona**************");
        vs.getLikeVisitaCoordinadaPorZona("uno", "ok").forEach(System.out::println);

        System.out.println("******************UPDATE visita *****************");
        visita = vs.getByVisitaId(2);
        visita.setConcretado("pendiente,se fue");
        vs.update(visita);

        System.out.println(vs.getByVisitaId(2));

        System.out.println("***************visita coordinada y concretado**************");
        vs.getLikeVisitaConcretada("ok", "pendiente").forEach(System.out::println);

        System.out.println("***************visita hora inicio y hora fin**************");
        vs.getByVisitaHorarioInicioFin(Horario._9hs, Horario._17hs).forEach(System.out::println);

        System.out.println("***************visita hora inicio **************");
        vs.getByVisitaHorarioInicio(Horario._9hs).forEach(System.out::println);

        System.out.println("************BORRAR chofer por ID(7)***********************************");
        vs.remove(vs.getByVisitaId(7));

        vs.getAll().forEach(System.out::println);

    }
}